package model;

import java.time.LocalDate;

public class Reserve {
    private int id;
    private int idService;
    private int idClient;
    private int reserve;
    private LocalDate date;

    public Reserve() {
    }

    public Reserve(int id, int idService, int idClient, int reserve, LocalDate date) {
        this.id = id;
        this.idService = idService;
        this.idClient = idClient;
        this.reserve = reserve;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdService() {
        return idService;
    }

    public void setIdService(int idService) {
        this.idService = idService;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public int getReserve() {
        return reserve;
    }

    public void setReserve(int reserve) {
        this.reserve = reserve;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

}
