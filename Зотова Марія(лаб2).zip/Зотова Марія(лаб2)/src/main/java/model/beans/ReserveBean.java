package model.beans;

import dao.ConnectionManager;
import dao.DaoReserve;
import dao.TableName;
import model.Reserve;

import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;

@ManagedBean(name = "billBean")
@SessionScoped
public class ReserveBean implements Serializable {
    private DaoReserve daoReserve;
    private Reserve selectedReserve;

    public Reserve getSelectedBill() {
        return selectedReserve;
    }

    public ReserveBean() {
        try {
            daoReserve = (DaoReserve) ConnectionManager.shared().getDAO(TableName.BILL);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public List<Reserve> getReserves() {
        List<Reserve> reserves = daoReserve.getAll();
        reserves.sort(Comparator.comparing(Reserve::getId));
        return reserves;
    }

    public String reserveInfo(Reserve reserve) {
        selectedReserve = reserve;
        return "edit";
    }

    public String saveSelectedReserve() {
        if(selectedReserve.getId() == -1) {
            daoReserve.save(selectedReserve);
        } else {
            daoReserve.update(selectedReserve);
        }
        return "menu";
    }
    public String addReserve() {
        selectedReserve = new Reserve(-1,0,0,0,null);
        return "edit";
    }
    public String removeReserve() {
        daoReserve.delete(selectedReserve);
        return "menu";
    }
}
