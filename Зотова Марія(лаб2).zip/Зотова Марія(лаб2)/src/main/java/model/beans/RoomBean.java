package model.beans;

import dao.ConnectionManager;
import dao.DaoRoom;
import dao.TableName;
import model.Room;

import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;

@ManagedBean(name = "serviceBean")
@SessionScoped
public class RoomBean implements Serializable {
    private DaoRoom daoRoom;
    private Room selectedRoom;

    public Room getSelectedRoom() {
        return selectedRoom;
    }

    public RoomBean() {
        try {
            daoRoom = (DaoRoom) ConnectionManager.shared().getDAO(TableName.SERVICE);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public List<Room> getRooms() {
        List<Room> rooms = daoRoom.getAll();
        rooms.sort(Comparator.comparing(Room::getId));
        return rooms;
    }

    public String roomInfo(Room room) {
        selectedRoom = room;
        return "edit";
    }

    public String saveSelectedRoom() {
        if(selectedRoom.getId() == -1) {
            daoRoom.save(selectedRoom);
        } else {
            daoRoom.update(selectedRoom);
        }
        return "menu";
    }
    public String addRoom() {
        selectedRoom = new Room(-1,"");
        return "edit";
    }
    public String removeRoom() {
        daoRoom.delete(selectedRoom);
        return "menu";
    }
}
