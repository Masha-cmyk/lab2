package dao;

import model.Room;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DaoRoom extends DaoGeneric<Room> {

    protected DaoRoom(Connection connection){
        super(connection, "rooms");
    }

    @Override
    Room getObjectFromResultSet(ResultSet resultSet) throws SQLException {
        int serviceId = resultSet.getInt("id");
        String name = resultSet.getString("name");
        return new Room(serviceId, name);
    }

    @Override
    String getInsertStatement(Room room) {
        return "INSERT INTO " + tableName + " (name)" +
                "VALUES ('" + room.getName() + "');";
    }

    @Override
    String getUpdateStatement(Room room) {
        return "UPDATE " + tableName
                + " SET name = '" + room.getName()
                + " WHERE id = " + room.getId() + ";";
    }

    @Override
    String getDeleteStatement(Room room) {
        return "DELETE FROM " + tableName + " WHERE id = " + room.getId() + ";";
    }
}
