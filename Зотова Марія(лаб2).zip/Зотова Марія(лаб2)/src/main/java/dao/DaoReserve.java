package dao;

import model.Reserve;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class DaoReserve extends DaoGeneric<Reserve> {

    protected DaoReserve(Connection connection) {
        super(connection, "reserves");
    }

    @Override
    Reserve getObjectFromResultSet(ResultSet resultSet) throws SQLException {
        int billId = resultSet.getInt("id");
        int idService = resultSet.getInt("idservice");
        int idClient = resultSet.getInt("idclient");
        int reserve = resultSet.getInt("reserve");
        LocalDate date = resultSet.getDate("date").toLocalDate();
        return new Reserve(billId, idService, idClient, reserve, date);
    }

    @Override
    String getInsertStatement(Reserve reserve) {
        return "INSERT INTO " + tableName + "(id service, idclient, reserve, date " +
                "VALUES (" + reserve.getIdService() + ", " + reserve.getIdClient() + ", " + reserve.getReserve() + ", " + reserve.getDate() + ");";
    }

    @Override
    String getUpdateStatement(Reserve reserve) {
        return "UPDATE " + tableName + " " +
                "SET idservice = " + reserve.getIdService()
                + ", idclient = " + reserve.getIdClient()
                + ", reserve = " + reserve.getReserve()
                + ", date" + reserve.getDate() +
                " WHERE id = " + reserve.getId() + ";";
    }

    @Override
    String getDeleteStatement(Reserve reserve) {
        return "DELETE FROM " + tableName + " WHERE id = " + reserve.getId() + ";";
    }
}
