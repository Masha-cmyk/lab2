package dao;

public enum TableName {
    CLIENT, SERVICE, BILL
}
