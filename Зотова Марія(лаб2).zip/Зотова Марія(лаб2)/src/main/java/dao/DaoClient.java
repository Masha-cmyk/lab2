package dao;

import model.Client;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DaoClient extends DaoGeneric<Client> {

    protected DaoClient(Connection connection){
        super(connection, "clients");
    }
    @Override
    Client getObjectFromResultSet(ResultSet resultSet) throws SQLException {
        int clientId = resultSet.getInt("id");
        String name = resultSet.getString("name");
        String surname = resultSet.getString("surname");
        return new Client(clientId, name,username);
    }

    @Override
    String getInsertStatement(Client client) {
        return "INSERT INTO " + tableName + "(name,username) " +
                "VALUES (" + client.getName() + ", " + client.getUsername() + ");";
    }

    @Override
    String getUpdateStatement(Client client) {
        return "UPDATE " + tableName + " SET name = '" + client.getName() + "'"
                + ",username = '" + client.getUsername() + "' WHERE id = " + client.getId() + ";";
    }

    @Override
    String getDeleteStatement(Client client) {
        return "DELETE FROM " + tableName + " WHERE id = " +client.getId() + ";";
    }
}
